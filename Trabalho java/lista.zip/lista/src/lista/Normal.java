


package lista;





/*
/**
 *
 * @author elima
 */
public class Normal extends Ingresso {
    void imprimeNormal(){
        System.out.println("ingresso normal");
    }
    
}
