
import java.util.Scanner;

public class NumeroDecrescente {
public static void main (String[] args) {
  Scanner in = new Scanner(System.in);
  int a = 0 ;
System.out.println("Digite numero inteiro" );
a = in.nextInt();

while (a>-1)
{
System.out.println(a);
a --;
}
}
} 