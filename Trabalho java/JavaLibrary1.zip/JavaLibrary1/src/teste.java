public class teste {
   public static void main(String[] args) {
		int Resultado = 0;
		long multiplica = 1;
		for (int i = 1; i < 30; i+= 2) {
			Resultado += i;
			multiplica *= (i+1);
			
		}
		System.out.println(Resultado);
		System.out.println(multiplica);
                
   }
}