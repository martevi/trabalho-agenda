public class Somaimpar {
   public static void main(String[] args) {
		int somaimpar = 0;
		long multiplicapar = 1;
		for (int i = 1; i < 30; i+= 2) {
			somaimpar += i;
			multiplicapar *= (i+1);
			System.out.println(i);
		}
		System.out.println(somaimpar);
		System.out.println(multiplicapar);
   }
}