# Plk-Ph
package primeiraaplicacao;

public class Carro {
//atributos
    
    private String chassi;
    private String cor;
    private String modelo;    

    //Getters and Setters
    
        public void setChassi(String chassi){
        
            this.chassi= chassi;
 }
        public String getChassi(){
        
            return chassi;
 }
        public void setCor(String cor){
        
            this.cor= cor;
 }
        public String getcor(){
        
            return cor;
 } 
        public void setModelo(String modelo){
        
            this.modelo= modelo;
 }
        public String getmodelo(){
        
            return modelo;
 }
}
